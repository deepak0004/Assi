import matplotlib.pyplot as plt
plt.plot([0.01,0.1, 0.3, 0.5, 0.7, 0.9], [0.07341553,0.02778602,0.13923246,0.14845778, 0.14641334, 0.15206854], 'r--')
#plt.axis([0, 6, 0, 20])
plt.xlabel('Learning Rate')
plt.ylabel('misclassification error')
plt.title('misclassification error vs learning rate')
plt.show()
