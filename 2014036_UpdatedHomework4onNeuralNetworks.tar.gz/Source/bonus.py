from __future__ import division, print_function, absolute_import
import tensorflow as tensor
import numpy as np
import matplotlib.pyplot as plt
import struct
import gzip
import itertools
from sklearn.grid_search import GridSearchCV
from sklearn.metrics import confusion_matrix
from sklearn.preprocessing import label_binarize
from scipy import interp
from sklearn.externals import joblib
from sklearn.neural_network import MLPClassifier
from sklearn.datasets import fetch_mldata

def flatten(x):
    result = []
    for el in x:
        if hasattr(el, "__iter__") and not isinstance(el, str):
            result.extend(flatten(el))
        else:
            result.append(el)
    return result
    
# '>I' makes x into a 4-byte string in big-endian order
def read_image(file_name, idx_image):
   img_file = gzip.open(file_name, 'rb')
   
   image = np.ndarray(shape=(28, 28))
   img_file.seek(16 + 28*28*idx_image)
	
   for row in range(28):
     for col in range(28):
         tmp_d = img_file.read(1)
         tmp_d = struct.unpack('>B',tmp_d)
         image[row, col] = tmp_d[0]

   img_file.close()
   return image

def read_label(file_name, idx_label):
   ind_file = gzip.open(file_name, 'rb')
   
   ind_file.seek(8 + idx_label)
   label = ind_file.read(1)
   label = struct.unpack('>B', label)

   ind_file.close()
   return str(label[0])

from tensorflow.examples.tutorials.mnist import input_data
mnist = input_data.read_data_sets("/tmp/data/", one_hot=True)
   
def preprocess():
    trainlabel = [] 
    trainimage = []
    trainlabel = np.array( trainlabel )
    trainimage = np.array( trainimage )
    testlabel = [] 
    testimage = []
    testlabel = np.array( testlabel ) 
    testimage = np.array( testimage )
    print('hi')
    for i in range(2):
        print(i)
        lab = read_label('train-labels-idx1-ubyte.gz', i)
        img = read_image('train-images-idx3-ubyte.gz', i)
        img = img.reshape(1, 784)
        img = flatten(img)
        img = [int(pp) for pp in img]
        print(lab)       
    
        for kkjj in range(784):
           img[kkjj] = int(img[kkjj])/255

        np.append(trainlabel, int(lab))
        np.append(trainimage, img)
        
    print('Hi')      
    for i in range(10000):
        lab = read_label('t10k-labels-idx1-ubyte.gz', i)
        img = read_image('t10k-images-idx3-ubyte.gz', i)
        img = img.reshape(1, 784)
        img = flatten(img)
        img = [int(pp) for pp in img]
        
        for kkjj in range(784):
           img[kkjj] = int(img[kkjj])/255
        
        np.append(testlabel, int(lab))
        np.append(testimage, img)  
        
    return trainimage, trainlabel, testimage, testlabel   

batchess = 512     # it will take 512 examples, apply feed forward and back prop to find best thetaa. After that take 512 more ags and so on.. 
learning_rate = 0.9
n_input = 784        
layer_hidnode1 = 100
layer_hidnode2 = 50  
training_epochs = 15 # feed forward + back prop -> one epochs

X = tensor.placeholder("float", [None, n_input])  # None: no height, n_input: 784 width 
thetaa = {
    'myfirencode': tensor.Variable(tensor.random_normal([n_input, layer_hidnode1])),
    'mysecencode': tensor.Variable(tensor.random_normal([layer_hidnode1, layer_hidnode2])),
    'myfirdecode': tensor.Variable(tensor.random_normal([layer_hidnode2, layer_hidnode1])),
    'mysecdecode': tensor.Variable(tensor.random_normal([layer_hidnode1, n_input])),
}
biases = {
    'myfirbiencode': tensor.Variable(tensor.random_normal([layer_hidnode1])),
    'mysecbiencode': tensor.Variable(tensor.random_normal([layer_hidnode2])),
    'myfirbidecode': tensor.Variable(tensor.random_normal([layer_hidnode1])),
    'mysecbidecode': tensor.Variable(tensor.random_normal([n_input])),
}

# ( input_data*thetaa ) + biases
def autoencode(x):
    firlayer = tensor.nn.sigmoid(tensor.add(tensor.matmul(x, thetaa['myfirencode']), biases['myfirbiencode']))
    seclayer = tensor.nn.sigmoid(tensor.add(tensor.matmul(firlayer, thetaa['mysecencode']), biases['mysecbiencode']))

    return seclayer
def autodecode(x):
    firlayer = tensor.nn.sigmoid(tensor.add(tensor.matmul(x, thetaa['myfirdecode']), biases['myfirbidecode']))
    seclayer = tensor.nn.sigmoid(tensor.add(tensor.matmul(firlayer, thetaa['mysecdecode']), biases['mysecbidecode']))

    return seclayer

autoencode_op = autoencode(X)
autodecode_op = autodecode(autoencode_op)

y_pred = autodecode_op
y_true = X

losss = tensor.reduce_mean(tensor.pow(y_true - y_pred, 2))
RMSoptimiser = tensor.train.RMSPropOptimizer(learning_rate).minimize(losss)
init = tensor.initialize_all_variables()

with tensor.Session() as sess:
    sess.run(init)
    no_of_size = int(mnist.train.num_examples/batchess)
    for ii in range(training_epochs):
        for i in range(no_of_size):
            batchh, batchhyy = mnist.train.next_batch(batchess)
            _, c = sess.run([RMSoptimiser, losss], feed_dict={X: batchh})
        print("Epoch:", '%04d' % (ii+1), "cost=", "{:.8f}".format(c))
    ####################################################################   
    #encode_decode = sess.run(y_pred, feed_dict={X: mnist.test.images[:10]})
    #f, a = plt.subplots(2, 10, figsize=(10, 2))
    #for i in range(10):
    #    a[0][i].imshow(np.reshape(mnist.test.images[i], (28, 28)))
    #    a[1][i].imshow(np.reshape(encode_decode[i], (28, 28)))
    #f.show()
    #plt.draw()