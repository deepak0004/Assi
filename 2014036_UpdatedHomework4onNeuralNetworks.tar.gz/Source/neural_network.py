from __future__ import print_function
import struct
import gzip
import itertools
import numpy as np
import matplotlib.pyplot as plt
from sklearn.grid_search import GridSearchCV
from sklearn.metrics import confusion_matrix
from sklearn.preprocessing import label_binarize
from scipy import interp
from sklearn.externals import joblib
from sklearn.neural_network import MLPClassifier
from sklearn.datasets import fetch_mldata
from sklearn.metrics import accuracy_score
'''
A multilayer perceptron (MLP) is a feedforward artificial neural network model that maps sets of input data onto a set of appropriate outputs. An MLP consists of multiple layers of nodes in a directed graph, with each layer fully connected to the next one.
'''

def plot_confusion_matrix(cm, classes,
                          normalize=False,
                          title='Confusion matrix',
                          cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)

    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, cm[i, j],
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')

def flatten(x):
    result = []
    for el in x:
        if hasattr(el, "__iter__") and not isinstance(el, str):
            result.extend(flatten(el))
        else:
            result.append(el)
    return result
    
# '>I' makes x into a 4-byte string in big-endian order
def read_image(file_name, idx_image):
   img_file = gzip.open(file_name, 'rb')
   
   image = np.ndarray(shape=(28, 28))
   img_file.seek(16 + 28*28*idx_image)
	
   for row in range(28):
     for col in range(28):
         tmp_d = img_file.read(1)
         tmp_d = struct.unpack('>B',tmp_d)
         image[row, col] = tmp_d[0]

   img_file.close()
   return image

def read_label(file_name, idx_label):
   ind_file = gzip.open(file_name, 'rb')
   
   ind_file.seek(8 + idx_label)
   label = ind_file.read(1)
   label = struct.unpack('>B', label)

   ind_file.close()
   return str(label[0])
   
def preprocess():
    trainlabel = [] 
    trainimage = []
    trainlabel = np.array( trainlabel )
    trainimage = np.array( trainimage )
    testlabel = [] 
    testimage = []
    testlabel = np.array( testlabel ) 
    testimage = np.array( testimage )
    print('hi')
    for i in range(2):
        print(i)
        lab = read_label('train-labels-idx1-ubyte.gz', i)
        img = read_image('train-images-idx3-ubyte.gz', i)
        img = img.reshape(1, 784)
        img = flatten(img)
        img = [int(pp) for pp in img]
        print(lab)       
    
        for kkjj in range(784):
           img[kkjj] = int(img[kkjj])/255

        np.append(trainlabel, int(lab))
        np.append(trainimage, img)
        
    print('Hi')      
    for i in range(10000):
        lab = read_label('t10k-labels-idx1-ubyte.gz', i)
        img = read_image('t10k-images-idx3-ubyte.gz', i)
        img = img.reshape(1, 784)
        img = flatten(img)
        img = [int(pp) for pp in img]
        
        for kkjj in range(784):
           img[kkjj] = int(img[kkjj])/255
        
        np.append(testlabel, int(lab))
        np.append(testimage, img)  
        
    return trainimage, trainlabel, testimage, testlabel   

#trainimage, trainlabel, testimage, testlabel = preprocess()
mnist = fetch_mldata('mnist-original')
trainimage = mnist.data[:60000]
trainlabel = mnist.target[:60000]            
trainimage = np.reshape( trainimage, (60000, 28*28) )
trainlabel = np.reshape( trainlabel, (60000, 1) )
trainlabel = flatten( trainlabel ) 

clf = MLPClassifier(hidden_layer_sizes=(500,250), max_iter=20, activation='tanh', verbose=10, random_state=1, learning_rate_init=0.000001)   
clf.fit(trainimage, trainlabel)
joblib.dump(clf, '../Models/FFNN_0.000001.pkl', compress=1)

testimage = mnist.data[60000:70000]
testlabel = mnist.target[60000:70000]
testlabel = np.reshape( testlabel, (10000, 1) )
testimage = np.reshape( testimage, (10000, 28*28) )
testlabel = flatten( testlabel )

pred = clf.predict(testimage)
pred = np.reshape(pred, (10000, 1))
pred = flatten( pred )

class_names = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

cnf_matrix = confusion_matrix(testlabel, pred)
np.set_printoptions(precision=2)

# Plot non-normalized confusion matrix
plt.figure()
plot_confusion_matrix(cnf_matrix, classes=class_names, title='Confusion matrix, without normalization')

# Plot normalized confusion matrix
plt.figure()
plot_confusion_matrix(cnf_matrix, classes=class_names, normalize=True, title='Normalized confusion matrix')

print( accuracy_score(testlabel, pred) )